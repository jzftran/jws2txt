#%%
from jws2txt.helpers.helpers import *

#%%


JWSFile(ofio.OleFileIO(r'C:\Users\makro\OneDrive\Pulpit\repos\jws2txt\temp\sample_CD_HT_Abs.jws')).unpacked_data